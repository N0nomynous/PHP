<?php
$myage = "None of your business <br/>";
print($myage);
$myage = 21;
print($myage . "<br/>");
$myage = 21.75;
print($myage);
?>
