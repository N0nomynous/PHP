<?php
$topModules[0] = "Internet Systems Development";
$topModules[1] = "Programming 1";
$topModules[2] = "Programming 2";
$topModules[3] = "OOAD";
$topModules[4] = "Software Engineering";
$topModules[5] = "Cyber Security"; // New module added
$topModules[6] = "Data Science"; // New module added

for ($count = 0; $count < count($topModules); $count++) {
    echo "$count module is $topModules[$count] <br/>";
}
?>
