<?php
for ($count = 0; $count <= 10; $count++) {
    echo "I must behave in class $count <br/>";
}
?>
