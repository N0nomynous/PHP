<?php
// Associative array with module codes as keys and marks as values
$mymarks = [
    "C0450-23S1BC" => 75, // Computer Architectures
    "C0454-23S1BC" => 80, // Digital Technologies and Professional Practice
    "C0556-23S1BC" => 70, // Network Systems
    "C0452-23S1BC" => 85, // Programming Concepts
    "C0456-23S1BC" => 90, // Web Development
    "C0453-23S2BC" => 88  // Application Programming
];

$total = 0; // Initialize total
?>

<html>
<head>
    <title>Module Marks Table</title>
</head>
<body>
    <table border="1" align="center">
        <tr>
            <th>Module Code</th>
            <th>Marks</th>
        </tr>
        <?php
        // Loop through the array and display marks in a table
        foreach ($mymarks as $index => $value) {
            echo "<tr><td>$index</td><td>$value</td></tr>";
            $total = $total + $value; // Calculate total marks
        }

        // Calculate average mark
        $average = $total / 6;
        ?>
        <tr>
            <td><b>Average Marks</b></td>
            <td><b><?php echo $average; ?></b></td>
        </tr>
    </table>
</body>
</html>
