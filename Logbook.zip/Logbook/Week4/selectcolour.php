<?php
session_start(); // Start session

// Ensure data exists before proceeding
if (!isset($_POST["selqty"]) || !isset($_POST["selsize"]) || !isset($_POST["txtprice"])) {
    echo "<h2>Error: Missing data in selectcolour.php. Please restart the process.</h2>";
    exit();
}

// Store data in variables
$selqty = htmlspecialchars($_POST["selqty"]);
$selsize = htmlspecialchars($_POST["selsize"]);
$price = htmlspecialchars($_POST["txtprice"]);

// 1️⃣ **Hidden Fields**
echo '<form action="confirmation.php" method="post">';
echo "<input type='hidden' name='selqty' value='$selqty'>";
echo "<input type='hidden' name='selsize' value='$selsize'>";
echo "<input type='hidden' name='txtprice' value='$price'>";

// 2️⃣ **Cookies**
setcookie("selqty", $selqty, time() + 3600, "/");
setcookie("selsize", $selsize, time() + 3600, "/");
setcookie("txtprice", $price, time() + 3600, "/");

// 3️⃣ **Session Variables**
$_SESSION["selqty"] = $selqty;
$_SESSION["selsize"] = $selsize;
$_SESSION["txtprice"] = $price;
?>

<p>Select the colour for the <?php echo $selqty; ?> widgets you are ordering:</p>

<select name="selcolour">
    <option value="white">White</option>
    <option value="red">Red</option>
    <option value="yellow">Yellow</option>
    <option value="green">Green</option>
    <option value="blue">Blue</option>
</select>

<br/><br/>  
<input type="submit" value="Buy">
</form>
