<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Validate input
if (!isset($_POST["selqty"]) || !isset($_POST["selsize"]) || !isset($_POST["selcolour"])) {
    echo "<h2>Error: Missing data. Please restart the process.</h2>";
    exit();
}

$qty = htmlspecialchars($_POST["selqty"]);
$size = htmlspecialchars($_POST["selsize"]);
$colour = htmlspecialchars($_POST["selcolour"]);

// Determine price per unit based on size
switch ($size) {
    case "small":
        $price_per_widget = 15.75;
        break;
    case "medium":
        $price_per_widget = 16.75;
        break;
    case "large":
        $price_per_widget = 17.75;
        break;
    case "extra_large":
        $price_per_widget = 18.75;
        break;
    default:
        echo "<h2>Error: Invalid size selected.</h2>";
        exit();
}

// Calculate total price
$total_price = $qty * $price_per_widget;

// Display confirmation
echo "<h2>Your order quantity is $qty.</h2><br/>";
echo "<h2>Size: $size.</h2><br/>";
echo "<h2>Price per widget: £" . number_format($price_per_widget, 2) . ".</h2><br/>";
echo "<h2>Selected Colour: $colour.</h2><br/>";
echo "<h2><strong>Total Cost: £" . number_format($total_price, 2) . "</strong></h2>";
?>