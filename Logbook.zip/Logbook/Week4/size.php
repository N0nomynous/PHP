<html>
<head>
    <title>Select Size</title>
</head>
<body>
    <?php
    if (!isset($_POST["selqty"])) {
        echo "<h2>Error: Quantity not selected. Please go back to <a href='shop.html'>shop.html</a>.</h2>";
        exit();
    }
    ?>

    <form action="selectcolour.php" method="post">
        <h2>Select the size for your <?php echo htmlspecialchars($_POST["selqty"]); ?> widgets</h2>

        <select name="selsize">
            <option value="small">Small (£15.75)</option>
            <option value="medium">Medium (£16.75)</option>
            <option value="large">Large (£17.75)</option>
            <option value="extra_large">Extra Large (£18.75)</option>
        </select>
        <br/><br/>

        <!-- Hidden field to pass quantity to next page -->
        <input type="hidden" name="selqty" value="<?php echo htmlspecialchars($_POST["selqty"]); ?>">

        <input type="submit" value="Next"/>
    </form>
</body>
</html>
