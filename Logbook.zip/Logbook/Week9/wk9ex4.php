<?php
// Start the session
session_start();

// Create the database connection
$conn = new mysqli("localhost", "root", "", "logbooks", 3307);

// Check if the form is submitted and 'selweek' is set in POST
if (isset($_POST['selweek'])) {
    // Use the selected week from the form
    $selected_week = $_POST['selweek'];
    $sql = "SELECT * FROM lotto WHERE wk = $selected_week";
    $result = mysqli_query($conn, $sql);

    // Fetch and display the result
    if ($row = mysqli_fetch_array($result)) {
        echo "Number 1 is  $row[number1]<br/>"; 
        echo "Number 2 is  $row[number2]<br/>"; 
        echo "Number 3 is  $row[number3]<br/>"; 
        echo "Number 4 is  $row[number4]<br/>"; 
        echo "Number 5 is  $row[number5]<br/>"; 
        echo "Number 6 is  $row[number6]<br/>"; 
    } else {
        echo "No data found for selected week.";
    }
} else {
    // If 'selweek' is not set, display the form
    $sql = "SELECT * FROM lotto";
    $result = mysqli_query($conn, $sql);

    echo "<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>";
    echo "<br/>Select the lottery week ";
    echo "<select name='selweek'>";
    while ($row = mysqli_fetch_array($result)) {
        echo "<option value='$row[wk]'>$row[wk]</option>";
    }
    echo "</select><br/>";
    echo "<input type='submit' value='Select' />";
    echo "</form>";
}

// Close the database connection
mysqli_close($conn);
?>
