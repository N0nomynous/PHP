<?php 
// Set the content type for audio playback
header("Content-Type: audio/wav");

// Create a database connection
$conn = new mysqli("localhost", "root", "", "logbooks", 3307);

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Validate `id` to prevent SQL injection
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];

    // Query to fetch audio from database
    $sql = "SELECT audio FROM monster WHERE id = ?";
    
    // Use prepared statements for security
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($audio);
    $stmt->fetch();
    $stmt->close();

    // Output audio
    echo $audio;
} else {
    echo "Invalid audio ID.";
}

// Close the database connection
$conn->close();
?>