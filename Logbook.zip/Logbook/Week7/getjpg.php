<?php

  // Prevent any accidental whitespace before output
  ob_clean();
  header("Content-Type: image/jpeg");

// Connect to the database
$conn = new mysqli("localhost", "root", "", "logbooks", 3307);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get the monster ID from the URL
$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

$sql = "SELECT image FROM monster WHERE id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $image);
mysqli_stmt_fetch($stmt);
mysqli_stmt_close($stmt);
mysqli_close($conn);

// If an image is found, display it
if ($image) {
    header("Content-Type: image/jpeg");
    echo $image;
} else {
    // Show a placeholder image if none is found
    header("Content-Type: image/png");
    readfile("placeholder.png");
}
?>
