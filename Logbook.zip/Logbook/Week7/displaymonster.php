<html>
<head></head>
<body>

<?php
// Create the database connection
$conn = new mysqli("localhost", "root", "", "logbooks", 3307);

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Define SQL query
$sql = "SELECT id, name FROM monster;";

// Execute the query (Pass the connection variable `$conn`)
$result = mysqli_query($conn, $sql);

echo "<table align='center' border='1'>";
echo "<tr><th width='200' align='left'>ID</th><th width='200' align='left'>Name</th><th>Audio</th><th>Image</th></tr>";

// Fetch and display results
while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>" . $row['id'] . "</td>"; // Fixed array key
    echo "<td>" . $row['name'] . "</td>"; // Fixed array key
    echo "<td><a href='getwav.php?id=" . $row['id']. "'>Click to play</a></td>";
    echo "<td><img src='getjpg.php?id=" . $row['id']. "' height='100' width='100'></td>"; // Fixed <img> tag
    echo "</tr>";
}

echo "</table>";

// Close the connection
mysqli_close($conn);
?>

</body>
</html>
