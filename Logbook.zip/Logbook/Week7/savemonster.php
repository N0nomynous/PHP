<?php 
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Create a recursive function to handle form submission
function processMonster() {
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES['monsterimage']) && isset($_FILES['monsteraudio'])) {
        // Database connection
        $conn = new mysqli("localhost", "root", "", "logbooks", 3307);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Process uploaded files
        $image = $_FILES['monsterimage']['tmp_name']; 
        $audio = $_FILES['monsteraudio']['tmp_name'];

        if ($image && $audio) {
            $imagedata = addslashes(file_get_contents($image));
            $audiodata = addslashes(file_get_contents($audio));

            // Secure input name
            $name = mysqli_real_escape_string($conn, $_POST['txtname']);

            // SQL Insert Query
            $sql = "INSERT INTO monster (name, image, audio) VALUES ('$name', '$imagedata', '$audiodata')";

            // Execute query
            if (mysqli_query($conn, $sql)) {
                echo "<div class='alert alert-success'>Monster saved successfully!</div>";
            } else {
                echo "<div class='alert alert-danger'>Error: " . mysqli_error($conn) . "</div>";
            }
        } else {
            echo "<div class='alert alert-warning'>Error: No file uploaded.</div>";
        }

        // Close connection
        mysqli_close($conn);

        // Recursively call the function to reload the form
        displayForm();
    } else {
        displayForm();
    }
}

// Function to display the form
function displayForm() {
?>
<!DOCTYPE html>
<html>
<head>
    <title>Monster Details</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2>Monster Details</h2>
        <form enctype="multipart/form-data" action="" method="post">
            <label>Monster Name:</label>
            <input type="text" name="txtname" size="15" class="form-control" required />
            <br/>

            <label>Monster Image:</label>
            <input type="file" name="monsterimage" accept="image/jpeg" class="form-control" required />
            <br/>

            <label>Monster Sound:</label>
            <input type="file" name="monsteraudio" accept="audio/basic" class="form-control" required />
            <br/>

            <input type="submit" class="btn btn-primary" value="Save" />
        </form>
    </div>
</body>
</html>
<?php
}

// Call the function to process the form
processMonster();
?>