<?php 
echo "User Agent: " . $_SERVER["HTTP_USER_AGENT"] . "<br>";

echo "Server Name: " . $_SERVER["SERVER_NAME"] . "<br>";

echo "Server Protocol: " . $_SERVER["SERVER_PROTOCOL"] . "<br>";
?>
