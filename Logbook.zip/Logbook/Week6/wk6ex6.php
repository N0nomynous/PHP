<?php
// Include the functions file
include("myfunctions.inc");

// Example values
$income = 50000;  // The income value
$taxRate = 20;    // Tax rate in percentage
$taxAllowance = 10000;  // Tax allowance

// Call the calculatetax function with the new parameters
$tax = calculatetax($income, $taxRate, $taxAllowance);

// Display the calculated tax
echo "The calculated tax is: $" . $tax;
?>