<?php
// Connect to the database
$conn = new mysqli("localhost", "root", "", "logbooks", 3307);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all records from the test table
$sql = "SELECT * FROM test";
$result = $conn->query($sql);
?>

<html>
<body>
<h2>Users List</h2>

<?php
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<a href='wk6ex2action.php?id=" . urlencode($row['name']) . "'>" . htmlspecialchars($row['name']) . "</a> ";
        echo "<a href='wk6ex4.php?id=" . urlencode($row['name']) . "' onclick='return confirm(\"Are you sure you want to delete this record?\")' style='color:red;'>[Delete]</a><br>";
    }
} else {
    echo "No records found.";
}
?>

</body>
</html>

<?php
$conn->close();
?>