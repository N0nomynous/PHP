<?php
include("myfunctions.inc");

html_header("My first function demo");
html_h1("These functions are going to save me lots of time");

html_h2("This is a subheading in h2 tags");

html_footer();
?>