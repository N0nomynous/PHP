<?php
// Connect to MySQL database
$conn = mysqli_connect("127.0.0.1", "root", "", "logbooks", 3307);
// Check if connection was successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if form data is received
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST["txtName"]) && !empty($_POST["txtEmail"]) && !empty($_POST["txtPhoneNumber"])) {
        
        // Escape user input to prevent SQL injection
        $name = mysqli_real_escape_string($conn, $_POST["txtName"]);
        $email = mysqli_real_escape_string($conn, $_POST["txtEmail"]);
        $phone = mysqli_real_escape_string($conn, $_POST["txtPhoneNumber"]);

        // Insert data into table
        $sql = "INSERT INTO test (name, email, phone_number) VALUES ('$name', '$email', '$phone')";

        if (mysqli_query($conn, $sql)) {
            echo "Data inserted successfully.<br/>";
        } else {
            echo "Error inserting data: " . mysqli_error($conn) . "<br/>";
        }
    } else {
        echo "All fields are required!<br/>";
    }

    // Retrieve and display data from table
    $sql = "SELECT * FROM test";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "{$row['name']}  {$row['email']}  {$row['phone_number']} <br/>";
        }
    } else {
        echo "No records found.<br/>";
    }
} else {
    echo "Form not submitted.<br/>";
}

// Close the database connection
mysqli_close($conn);
?>
