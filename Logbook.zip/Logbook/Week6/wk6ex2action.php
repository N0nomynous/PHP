<?php
// Connect to MySQL server
$conn = mysqli_connect("localhost", "root", "", "logbooks", 3307); // Change port if needed

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get the 'id' parameter safely
$id = mysqli_real_escape_string($conn, $_GET['id'] ?? '');

// Fetch record if 'id' is provided
$row = null;
if (!empty($id)) {
    $sql = "SELECT * FROM test WHERE id = '$id'"; // Assuming 'id' is the primary key
    $result = mysqli_query($conn, $sql);

    if (!$result) {
        die("Query failed: " . mysqli_error($conn));
    }

    $row = mysqli_fetch_assoc($result);
    mysqli_free_result($result); // Free memory
}

// Handle form submission (update record)
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['btnsubmit'])) {
    $phone = mysqli_real_escape_string($conn, $_POST['txttelno']);
    $email = mysqli_real_escape_string($conn, $_POST['txtemail']);

    $update_sql = "UPDATE test SET phone_number = '$phone', email = '$email' WHERE id = '$id'";
    
    if (mysqli_query($conn, $update_sql)) {
        echo "Record updated successfully!";
        header("Refresh: 1; url=wk6ex3.php"); // Redirect after 1 second
        exit();
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}

// Close connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Record</title>
</head>
<body>
    <h2>Edit Record</h2>
    <form action="" method="post">
        Name:
        <input type="text" name="txtname" value="<?php echo htmlspecialchars($row['name'] ?? ''); ?>" /><br/>

        Phone number:
        <input type="text" name="txttelno" value="<?php echo htmlspecialchars($row['phone_number'] ?? ''); ?>" /><br/>

        Email:
        <input type="text" name="txtemail" value="<?php echo htmlspecialchars($row['email'] ?? ''); ?>" /><br/>

        <input type="submit" name="btnsubmit" value="Save"/>
    </form>
</body>
</html>