<?php
// Database connection settings
$host = "localhost";
$user = "root";
$password = "";
$database = "logbooks";
$port = 3307; // Change if necessary

// Establishing a connection
$connection = new mysqli($host, $user, $password, $database, $port);

// Checking if the connection was successful
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Retrieve ID using GET or POST, and sanitize input
$record_id = null;
if (isset($_GET['id'])) {
    $record_id = $connection->real_escape_string($_GET['id']);
} elseif (isset($_POST['id'])) {
    $record_id = $connection->real_escape_string($_POST['id']);
}

// Proceed with deletion if a valid ID is provided
if ($record_id) {
    // Prepare DELETE SQL statement
    $delete_query = "DELETE FROM test WHERE name = '$record_id'";

    // Execute the query and check if it was successful
    if ($connection->query($delete_query)) {
        echo "Record successfully deleted! <a href='wk6ex2.php'>Back to records</a>";
    } else {
        echo "Error occurred while deleting record: " . $connection->error;
    }
} else {
    // Handle invalid or missing ID
    echo "Invalid or missing ID. <a href='wk6ex2.php'>Back to records</a>";
}

// Close the database connection
$connection->close();
?>