<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Ensure form data is received
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST["radcourse"])) {
        switch ($_POST["radcourse"]) {
            case "HNC":
                echo "You have selected an HNC course.";
                break;
            case "HND":
                echo "You have selected an HND course.";
                break;
            case "BSC":
                echo "You have selected a BSC course.";
                break;
            case "Part Time BSC":
                echo "You have selected a Part Time BSC course.";
                break;
            default:
                echo "No course selected.";
                break;
        }
    } else {
        echo "No course selected.";
    }
} else {
    echo "<h3>No form data received. Please fill out the form first.</h3>";
}
?>
