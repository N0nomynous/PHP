<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>
<html>
<head>
    <title>Response to Form</title>
</head>
<body>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        echo "<h2>Form Submission Response</h2>";

        // Display name
        if (!empty($_POST["txtname"])) {
            echo "Your name is: " . htmlspecialchars($_POST["txtname"]) . "<br/>";
        } else {
            echo "Name not provided.<br/>";
        }

        // Display gender
        if (!empty($_POST["radsex"])) {
            echo "Your gender is: " . htmlspecialchars($_POST["radsex"]) . "<br/>";
        } else {
            echo "Gender not selected.<br/>";
        }

        // Display occupation
        if (!empty($_POST["seloccupation"])) {
            echo "Your occupation is: " . htmlspecialchars($_POST["seloccupation"]) . "<br/>";
        } else {
            echo "Occupation not selected.<br/>";
        }
    } else {
        echo "<h3>No form data received. Please fill out the form first.</h3>";
    }
    ?>
</body>
</html>

