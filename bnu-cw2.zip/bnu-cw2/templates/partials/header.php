<html>

   <head>
      <title>BNU Student Web Application</title>
      <!-- styles and JS here -->

   </head>

   <body>
