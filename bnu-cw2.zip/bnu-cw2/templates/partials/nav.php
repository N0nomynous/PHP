
<div id="main-nav">

   <a href="modules.php">My Modules</a> |
   <a href="assignmodule.php">Assign Module</a> |
   <a href="details.php">My Details</a> |
   <a href="logout.php">Logout</a>

</div>
